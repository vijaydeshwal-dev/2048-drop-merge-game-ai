# 2048 Ball Drop Merge Game

Play it live: [GitHub Pages](https://vijaydeshwal-dev.github.io/2048-drop-merge-game-ai/)

A React implementation of the 2048 Ball Drop Merge Game.

## Local Development

```bash
npm install
npm start
```

## Deploy to GitHub Pages

```bash
npm run deploy
```