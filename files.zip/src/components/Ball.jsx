import React from "react";

export default function Ball({ value }) {
  return (
    <div className={`ball ball-${value}`}>
      {value}
    </div>
  );
}