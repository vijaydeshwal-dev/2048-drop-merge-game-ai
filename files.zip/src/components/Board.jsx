import React from "react";
import Ball from "./Ball";

export default function Board({ grid, onDrop, disabled }) {
  return (
    <div className="board">
      <div className="board-row">
        {grid[0].map((_, colIdx) => (
          <button
            key={colIdx}
            className="drop-btn"
            onClick={() => onDrop(colIdx)}
            disabled={disabled}
            aria-label={`Drop ball in column ${colIdx + 1}`}
          >
            ▼
          </button>
        ))}
      </div>
      {grid.map((row, rowIdx) => (
        <div className="board-row" key={rowIdx}>
          {row.map((cell, colIdx) => (
            <div className="board-cell" key={colIdx}>
              {cell && <Ball value={cell} />}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}