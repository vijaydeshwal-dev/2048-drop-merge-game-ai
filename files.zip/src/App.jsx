import React, { useState } from "react";
import Board from "./components/Board";
import "./styles.css";

const ROWS = 7;
const COLS = 5;

function getEmptyGrid() {
  return Array.from({ length: ROWS }, () => Array(COLS).fill(null));
}

function getRandomBallValue() {
  return Math.random() < 0.9 ? 2 : 4;
}

function mergeBalls(grid, setScore) {
  let merged = false;
  let tempGrid = grid.map(row => row.slice());
  let scoreToAdd = 0;

  // Only merge vertically
  for (let col = 0; col < COLS; col++) {
    for (let row = ROWS - 1; row > 0; row--) {
      if (
        tempGrid[row][col] &&
        tempGrid[row][col] === tempGrid[row - 1][col]
      ) {
        tempGrid[row][col] *= 2;
        scoreToAdd += tempGrid[row][col];
        tempGrid[row - 1][col] = null;
        merged = true;
      }
    }
  }

  // Drop balls down after merge
  for (let col = 0; col < COLS; col++) {
    let pointer = ROWS - 1;
    for (let row = ROWS - 1; row >= 0; row--) {
      if (tempGrid[row][col]) {
        tempGrid[pointer][col] = tempGrid[row][col];
        if (pointer !== row) tempGrid[row][col] = null;
        pointer--;
      }
    }
  }

  if (merged) setScore(prev => prev + scoreToAdd);
  return tempGrid;
}

export default function App() {
  const [grid, setGrid] = useState(getEmptyGrid());
  const [score, setScore] = useState(0);
  const [nextBall, setNextBall] = useState(getRandomBallValue());
  const [gameOver, setGameOver] = useState(false);

  function handleDrop(col) {
    if (gameOver) return;
    let rowToDrop = null;
    for (let row = ROWS - 1; row >= 0; row--) {
      if (!grid[row][col]) {
        rowToDrop = row;
        break;
      }
    }
    if (rowToDrop === null) {
      return;
    }
    const newGrid = grid.map(arr => arr.slice());
    newGrid[rowToDrop][col] = nextBall;

    // Merge after drop
    let mergedGrid = mergeBalls(newGrid, setScore);

    setGrid(mergedGrid);
    setNextBall(getRandomBallValue());

    // Check game over
    if (mergedGrid[0].some(cell => cell !== null)) {
      setGameOver(true);
    }
  }

  function handleRestart() {
    setGrid(getEmptyGrid());
    setScore(0);
    setNextBall(getRandomBallValue());
    setGameOver(false);
  }

  return (
    <div className="app">
      <h1>2048 Ball Drop Merge Game</h1>
      <div className="score">Score: {score}</div>
      <div className="next-ball">
        Next Ball: <span className="ball-preview">{nextBall}</span>
      </div>
      <Board grid={grid} onDrop={handleDrop} disabled={gameOver} />
      <div style={{ marginTop: 16 }}>
        {gameOver && (
          <div>
            <div style={{ fontWeight: "bold", color: "red" }}>Game Over!</div>
            <button onClick={handleRestart}>Restart</button>
          </div>
        )}
      </div>
    </div>
  );
}